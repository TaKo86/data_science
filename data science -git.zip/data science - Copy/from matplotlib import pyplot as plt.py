from matplotlib import pyplot as plt 

print(plt.style.available) # prininting all available printing styles

agex_x=[12,18,20,22,21,24,25,23,45,227,34,44,54,55,53,32,19,23,41]

all_dev=[17888,18000,19000,215000,24000,2450000,22000,70000,650000,68000,70000,900000,910000,5900000,4900000,20000,21000,22000,23000]

js_dev=[15000,140000,16512,20100,240000,24000,245650,695000,64521,848394,34993,6000944,85839202,9393902,843848,850000,860000,870000,880000]

python_dev=[15040,140050,56512,20100,540000,27000,247650,695800,84521,8788394,349793,6700944,9839202,939302,63848,65000,66000,67000,68000]

plt.plot(agex_x, all_dev, label="All")# plot line graph for salires of all dev
plt.plot(agex_x, js_dev, label="Javascript") #plot line graph for js
plt.plot (agex_x , python_dev, label="python") #plot line python

plt.title ("avg dev salary")
plt.legend()# show legend to identify the lines 
plt.xlabel("age")
plt.ylabel("salary")
plt.grid()
plt.show()