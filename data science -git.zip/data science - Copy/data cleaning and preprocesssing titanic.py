#title: data cleaning and preprocessing ( filling missing values until row 35)

import pandas as pd

#load dataset
df=pd.read_csv("https://raw.githubusercontent.com/datasciencedojo/datasets/master/titanic.csv")



# fill missing values in "age" for the first 35 entries , 0 -35

df.loc[:35, 'Age']=df.loc[:35,'Age'].fillna(df['Age'].median())
#select rows 0-35 in the age cp;lumn and replace missing vlaues with the median age

#fill missing values in 'embarked' for the first 35 rows
df.loc[:35, 'Embarked']=df.loc[:35, 'Embarked'].fillna(df['Embarked'].mode()[0])
# replace missing values in emabarked 0-35 rows tihe the most frequent port(mode)

#fill missing values in 'cabin' for the first 35 rows
df.loc[:35, 'Cabin']=df.loc[:35, 'Cabin'].fillna(df['Cabin'].mode()[0])

#convert "sex" colum to numberic male = 0 female = 1
df["Sex"]=df["Sex"].map({"male":0, "female":1})
# convert categoriical  gender values into numeric values so that ml models canread it better


#one-hot encode the "embarked" columnn ( drop one dummy to avoid multicollinearity)

df=pd.get_dummies(df, columns=["Embarked"], drop_first= True)



# display first 40 rows to confrom change

print("first 40 rows after processing")


print(df.head(40))