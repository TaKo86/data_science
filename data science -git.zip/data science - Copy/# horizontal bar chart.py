# horizontal bar chart

from matplotlib import pyplot as plt
import numpy as np


languages = ['C', 'HTML/CSS', 'Ruby', 'C#', 'Go', 'Python',
             'bash', 'assembly', 'ts', 'js', 'php', 'C++', 'sql', 'others']

# make sure there are exactly as many frequency values as languages
frequency = [18000, 5500, 7000, 360000, 37000, 75000,
             38000, 32000, 7500, 38000, 32000, 4000, 190000, 580000]

# sort data by frequency if desired
pairs = sorted(zip(frequency, languages))  # combine and sort by freq
frequency_list, languages_list = zip(*pairs)  # unpack back into two lists

plt.barh(languages_list, frequency_list) # create a bar graph of these lists

plt.title("language usage", fontsize=20)
plt.ylabel('langauges')
plt.xlabel('users')
plt.tight_layout()


plt.show()

