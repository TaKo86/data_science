#title: data exploration with titanic data set

import pandas as pd

df=pd.read_csv("https://raw.githubusercontent.com/datasciencedojo/datasets/master/titanic.csv")


print("data set overview")
print(df.head(35)) #display first 35 rows

#show summary stats of numeric columns\
print("\n data summary")
print(df.describe()) # generate summary stats( count, mean std etc)

# show count of missing values
print("\n missing values")
print(df.isnull().sum()) # number of missing vlaues


