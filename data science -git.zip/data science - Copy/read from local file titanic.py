import pandas as pd 
df = pd.read_csv("titanic_data.csv")

df.loc[:11, 'Fare'] = df.loc[:11, 'Fare'].fillna(df['Fare'].median())


print(df)